# Software Requirements Specification (SRS)

**AI-Driven Student Performance Prediction System**

## Purpose
Predict student performance (Good/Average/Poor) using academic features like attendance, grades, and study hours. Provide early alerts for at-risk students and offer a dashboard for visualization.

## Key Features
- Data preprocessing and feature selection
- Train/evaluate ML models (Random Forest, Logistic Regression, SVM)
- Web dashboard using Streamlit
- Store datasets in /data and model artifacts in /model
