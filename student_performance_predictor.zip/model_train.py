"""Skeleton for data loading, preprocessing, training and saving a model."""

import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib

def load_data(path):
    return pd.read_csv(path)

def preprocess(df):
    # Placeholder preprocessing - adapt to your dataset
    df = df.copy()
    df.fillna(df.mean(numeric_only=True), inplace=True)
    features = ['attendance','assignment_avg','midterm','study_hours']
    X = df[features]
    y = df['performance']  # expected to be labeled as Good/Average/Poor
    return X, y

def train(path='data/student_data.csv'):
    df = load_data(path)
    X, y = preprocess(df)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    joblib.dump({'model': model, 'scaler': scaler}, 'model/artifact.pkl')
    print('Model trained and saved to model/artifact.pkl')

if __name__ == '__main__':
    train()
