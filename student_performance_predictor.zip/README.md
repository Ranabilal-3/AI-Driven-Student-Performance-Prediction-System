# AI-Driven Student Performance Prediction System

An AI-based system that predicts student academic performance using machine learning.
It analyzes data like attendance, grades, and assignments to identify at-risk students early.
Includes a Streamlit dashboard for input, predictions, and analytics.

## Structure
- app.py                # Streamlit app (frontend)
- model_train.py        # Data processing & model training skeleton
- requirements.txt
- data/                 # put datasets (CSV) here
- notebooks/            # optional Jupyter notebooks
- srs.md                # Software Requirements Specification
