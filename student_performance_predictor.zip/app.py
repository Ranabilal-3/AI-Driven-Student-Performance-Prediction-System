import streamlit as st
import pandas as pd
import numpy as np
import pickle
from sklearn.ensemble import RandomForestClassifier

st.title('AI Student Performance Predictor')
st.write('Input student details to predict performance (Good/Average/Poor).')

# Simple input form
attendance = st.number_input('Attendance (%)', min_value=0.0, max_value=100.0, value=75.0)
assignment_avg = st.number_input('Average Assignment Score (0-100)', min_value=0.0, max_value=100.0, value=70.0)
midterm = st.number_input('Midterm Score (0-100)', min_value=0.0, max_value=100.0, value=68.0)
study_hours = st.number_input('Study Hours per Week', min_value=0.0, max_value=100.0, value=10.0)

if st.button('Predict'):
    # NOTE: This is a placeholder. Replace with your trained model.
    # We'll use a simple rule-based proxy if model not available.
    score = 0.4*attendance + 0.3*assignment_avg + 0.2*midterm + 0.1*(study_hours*5)
    if score >= 75:
        pred = 'Good'
    elif score >= 50:
        pred = 'Average'
    else:
        pred = 'Poor'
    st.success(f'Predicted Performance: {pred}')
    st.write('Score (proxy):', round(score,2))
