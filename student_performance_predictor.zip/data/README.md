Place your CSV dataset(s) in this folder. Example file name: student_data.csv
Columns expected: attendance, assignment_avg, midterm, study_hours, performance
